using Microsoft.EntityFrameworkCore;
using TesteCrud.Data;

var builder = WebApplication.CreateBuilder(args);

// Adicione o servi�o do DbContext
builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseMySql("server=localhost;database=crud;uid=root;pwd=123456;", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.40-mysql"), mySqlOptions => mySqlOptions.EnableRetryOnFailure()));

// Adicione servi�os para controladores
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure o pipeline de solicita��o HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Produtos}/{action=Index}/{id?}");

app.Run();
