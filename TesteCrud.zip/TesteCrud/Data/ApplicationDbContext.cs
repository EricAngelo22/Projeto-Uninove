﻿using Microsoft.EntityFrameworkCore;
using TesteCrud.Models;

namespace TesteCrud.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Produtos> Produtos { get; set; }
    }
}

